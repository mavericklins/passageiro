import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';
import 'firebase_options.dart';

import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/ride_request_screen.dart';
import 'screens/buscando_motoristas_screen.dart';
import 'screens/home/confirmacao_corrida.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    print('✅ Firebase inicializado');

    if (!kIsWeb) {
      print('✅ Login persistente automático no ANDROID');
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        print('✅ Usuário já logado: ${user.email}');
      }
    } else {
      await FirebaseAuth.instance.setPersistence(Persistence.LOCAL);
      print('✅ Login permanente configurado para WEB');
    }

  } catch (e) {
    print('❌ Erro ao inicializar Firebase: $e');
  }

  runApp(VelloApp());
}

class VelloApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vello',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AuthWrapper(),
      routes: {
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/home': (context) {
          final user = FirebaseAuth.instance.currentUser;
          final userName = user?.displayName ?? user?.email?.split('@')[0] ?? 'Usuário';
          return HomeScreen(userName: userName);
        },
        '/ride_request': (context) => RideRequestScreen(),
        '/confirmacao_corrida': (context) {
          final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
          final enderecoInicial = args?['enderecoInicial'] ?? 'Endereço não informado';
          return ConfirmacaoCorridaScreen(enderecoInicial: enderecoInicial);
        },
        '/buscando_motoristas': (context) {
          final args = ModalRoute.of(context)?.settings.arguments;

          if (args != null && args is Map<String, dynamic>) {
            final corridaId = args['corridaId']?.toString() ?? 'temp_${DateTime.now().millisecondsSinceEpoch}';

            LatLng? localizacaoPassageiro;
            if (args['origin'] != null && args['origin'] is Map) {
              final origin = args['origin'] as Map;
              final lat = origin['latitude'];
              final lng = origin['longitude'];
              if (lat != null && lng != null) {
                localizacaoPassageiro = LatLng(lat.toDouble(), lng.toDouble());
              }
            } else if (args['localizacaoPassageiro'] != null) {
              localizacaoPassageiro = args['localizacaoPassageiro'] as LatLng?;
            }

            return BuscandoMotoristasScreen(
              corridaId: corridaId,
              localizacaoPassageiro: localizacaoPassageiro,
            );
          }

          return BuscandoMotoristasScreen(
            corridaId: 'temp_${DateTime.now().millisecondsSinceEpoch}',
            localizacaoPassageiro: null,
          );
        },
      },
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            backgroundColor: Color(0xFFF8F9FA),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: Color(0xFFFF8C42),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Icon(Icons.local_taxi, color: Colors.white, size: 40),
                  ),
                  SizedBox(height: 24),
                  Text('Vello', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF1B3A57))),
                  SizedBox(height: 16),
                  CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF8C42))),
                ],
              ),
            ),
          );
        }

        if (snapshot.hasData && snapshot.data != null) {
          final user = snapshot.data!;
          print('✅ Usuário autenticado: ${user.email}');
          final userName = user.displayName ?? user.email?.split('@')[0] ?? 'Usuário';
          return HomeScreen(userName: userName);
        }

        return LoginScreen();
      },
    );
  }
}
