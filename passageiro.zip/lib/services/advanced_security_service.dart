import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/feature_flags.dart';

class AdvancedSecurityService {
  static final AdvancedSecurityService _instance = AdvancedSecurityService._internal();
  factory AdvancedSecurityService() => _instance;
  AdvancedSecurityService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool get isEnabled => FeatureFlags.enableAdvancedSOS;

  Future<void> initialize() async {
    if (!isEnabled) return;
    // Inicialização de recursos avançados
    print('Advanced Security Service inicializado');
  }

  Future<void> enablePanic() async {
    if (!isEnabled) return;
    // Ativar modo pânico
    print('Modo pânico ativado');
  }

  Future<void> suggestSafePoints() async {
    if (!isEnabled) return;
    
    try {
      final position = await Geolocator.getCurrentPosition();

      // Buscar pontos seguros próximos (delegacias, hospitais, etc)
      final pontos = await _firestore
          .collection('pontos_seguros')
          .where('ativo', isEqualTo: true)
          .get();

      final pontosProximos = <Map<String, dynamic>>[];

      for (final doc in pontos.docs) {
        final data = doc.data();
        final distance = Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          data['latitude'],
          data['longitude'],
        );

        if (distance <= 5000) {
          pontosProximos.add({
            ...data,
            'distance': distance,
            'id': doc.id,
          });
        }
      }

      if (pontosProximos.isNotEmpty) {
        pontosProximos.sort((a, b) => a['distance'].compareTo(b['distance']));
        final pontoProximo = pontosProximos.first;
        final distanciaKm = (pontoProximo['distance'] / 1000).toStringAsFixed(1);

        print('Ponto seguro mais próximo: ${pontoProximo['nome']} - $distanciaKm km');
        
        // Aqui poderia implementar notificação
        _notifyUser('Ponto seguro próximo', 'O ponto mais próximo está a $distanciaKm km.');
      }
    } catch (e) {
      print('Erro ao sugerir pontos seguros: $e');
    }
  }

  Future<void> shareLocation() async {
    if (!isEnabled) return;
    
    try {
      final position = await Geolocator.getCurrentPosition();
      final locationUrl = 'https://maps.google.com/?q=${position.latitude},${position.longitude}';
      
      // Compartilhar via WhatsApp ou SMS
      final message = 'EMERGÊNCIA - Minha localização atual: $locationUrl';
      
      // Aqui poderia integrar com contatos de emergência
      print('Localização compartilhada: $message');
      
      _notifyUser('Localização compartilhada', 'Sua localização foi enviada aos contatos de emergência.');
    } catch (e) {
      print('Erro ao compartilhar localização: $e');
    }
  }

  Future<void> callEmergency(String number) async {
    if (!isEnabled) return;
    
    try {
      final uri = Uri(scheme: 'tel', path: number);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      }
      
      _notifyUser('Ligação de emergência', 'Ligando para $number...');
    } catch (e) {
      print('Erro ao fazer ligação: $e');
    }
  }

  Future<void> sendEmergencyMessage() async {
    if (!isEnabled) return;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Obter contatos de emergência
      final contacts = await _firestore
          .collection('usuarios')
          .doc(userId)
          .collection('contatos_emergencia')
          .get();

      final position = await Geolocator.getCurrentPosition();
      final locationUrl = 'https://maps.google.com/?q=${position.latitude},${position.longitude}';

      for (final contactDoc in contacts.docs) {
        final contact = contactDoc.data();
        final phone = contact['phone'] as String;
        final name = contact['name'] as String;

        final message = '''
🚨 ALERTA DE EMERGÊNCIA

Olá $name, estou em uma situação de emergência e preciso de ajuda.

📍 Minha localização atual: $locationUrl

🕐 Horário: ${DateTime.now().toString()}

Por favor, entre em contato comigo ou com as autoridades se necessário.

Mensagem enviada automaticamente pelo app Vello.
        ''';

        // Enviar via WhatsApp
        await _sendWhatsAppMessage(phone, message);
      }

      _notifyUser('Mensagem de emergência', 'Mensagens enviadas aos contatos de emergência!');
    } catch (e) {
      print('Erro ao enviar mensagem: $e');
    }
  }

  Future<void> _sendWhatsAppMessage(String phone, String message) async {
    try {
      String cleanPhone = phone.replaceAll(RegExp(r'[^\d]'), '');
      if (!cleanPhone.startsWith('55')) {
        cleanPhone = '55$cleanPhone';
      }

      final whatsappUrl = 'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}';
      
      if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
        await launchUrl(Uri.parse(whatsappUrl), mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      print('Erro ao enviar WhatsApp: $e');
    }
  }

  Future<void> activateEmergency() async {
    if (!isEnabled) return;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Salvar no Firestore que emergência foi ativada
      await _firestore.collection('emergency_alerts').add({
        'userId': userId,
        'timestamp': FieldValue.serverTimestamp(),
        'type': 'passenger_sos',
        'status': 'active',
        'location': await _getCurrentLocationData(),
      });

      // Enviar mensagens para contatos
      await sendEmergencyMessage();
      
      // Sugerir pontos seguros
      await suggestSafePoints();

      _notifyUser('Emergência ativada', 'Todos os protocolos de segurança foram acionados!');
    } catch (e) {
      print('Erro ao ativar emergência: $e');
    }
  }

  Future<void> cancelEmergency() async {
    if (!isEnabled) return;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Atualizar status no Firestore
      final alerts = await _firestore
          .collection('emergency_alerts')
          .where('userId', isEqualTo: userId)
          .where('status', isEqualTo: 'active')
          .get();

      for (final alert in alerts.docs) {
        await alert.reference.update({
          'status': 'cancelled',
          'cancelledAt': FieldValue.serverTimestamp(),
        });
      }

      _notifyUser('Emergência cancelada', 'O alerta de emergência foi cancelado.');
    } catch (e) {
      print('Erro ao cancelar emergência: $e');
    }
  }

  Future<Map<String, dynamic>> _getCurrentLocationData() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      return {
        'latitude': position.latitude,
        'longitude': position.longitude,
        'accuracy': position.accuracy,
        'timestamp': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {};
    }
  }

  void _notifyUser(String title, String message) {
    // Aqui poderia implementar notificações push
    print('$title: $message');
  }

  // Monitoramento em tempo real durante corrida
  Future<void> startRideTracking(String rideId) async {
    if (!isEnabled) return;
    
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Iniciar tracking da corrida
      await _firestore.collection('ride_tracking').doc(rideId).set({
        'userId': userId,
        'rideId': rideId,
        'startedAt': FieldValue.serverTimestamp(),
        'isActive': true,
        'trackingPoints': [],
      });

      print('Tracking da corrida iniciado: $rideId');
    } catch (e) {
      print('Erro ao iniciar tracking: $e');
    }
  }

  Future<void> updateRideLocation(String rideId) async {
    if (!isEnabled) return;
    
    try {
      final locationData = await _getCurrentLocationData();
      
      await _firestore.collection('ride_tracking').doc(rideId).update({
        'lastUpdate': FieldValue.serverTimestamp(),
        'currentLocation': locationData,
        'trackingPoints': FieldValue.arrayUnion([locationData]),
      });
    } catch (e) {
      print('Erro ao atualizar localização: $e');
    }
  }

  Future<void> stopRideTracking(String rideId) async {
    if (!isEnabled) return;
    
    try {
      await _firestore.collection('ride_tracking').doc(rideId).update({
        'isActive': false,
        'endedAt': FieldValue.serverTimestamp(),
      });

      print('Tracking da corrida finalizado: $rideId');
    } catch (e) {
      print('Erro ao parar tracking: $e');
    }
  }
}