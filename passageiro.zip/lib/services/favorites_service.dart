import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/address_model.dart';

enum FavoriteType { home, work, other }

class FavoriteAddress {
  final String id;
  final String name;
  final FavoriteType type;
  final AddressModel address;
  final DateTime createdAt;
  final String? icon;
  
  FavoriteAddress({
    required this.id,
    required this.name,
    required this.type,
    required this.address,
    required this.createdAt,
    this.icon,
  });
  
  factory FavoriteAddress.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return FavoriteAddress(
      id: doc.id,
      name: data['name'] ?? '',
      type: FavoriteType.values.firstWhere(
        (t) => t.name == data['type'],
        orElse: () => FavoriteType.other,
      ),
      address: AddressModel.fromMap(data['address']),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      icon: data['icon'],
    );
  }
  
  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'type': type.name,
      'address': address.toMap(),
      'createdAt': Timestamp.fromDate(createdAt),
      'icon': icon,
    };
  }
  
  String get displayIcon {
    switch (type) {
      case FavoriteType.home:
        return '🏠';
      case FavoriteType.work:
        return '🏢';
      case FavoriteType.other:
        return icon ?? '📍';
    }
  }
}

class FavoritesService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  
  static String get _userId => _auth.currentUser!.uid;
  
  static CollectionReference get _favoritesCollection =>
      _firestore.collection('usuarios').doc(_userId).collection('favoritos');
  
  // Adicionar endereço favorito
  static Future<bool> addFavorite({
    required String name,
    required FavoriteType type,
    required AddressModel address,
    String? icon,
  }) async {
    try {
      // Verificar se já existe um favorito do mesmo tipo (casa/trabalho)
      if (type != FavoriteType.other) {
        final existingQuery = await _favoritesCollection
            .where('type', isEqualTo: type.name)
            .get();
            
        if (existingQuery.docs.isNotEmpty) {
          // Atualizar o existente
          await existingQuery.docs.first.reference.update({
            'name': name,
            'address': address.toMap(),
            'icon': icon,
          });
          return true;
        }
      }
      
      final favorite = FavoriteAddress(
        id: '',
        name: name,
        type: type,
        address: address,
        createdAt: DateTime.now(),
        icon: icon,
      );
      
      await _favoritesCollection.add(favorite.toFirestore());
      return true;
    } catch (e) {
      print('Erro ao adicionar favorito: $e');
      return false;
    }
  }
  
  // Listar favoritos
  static Stream<List<FavoriteAddress>> getFavorites() {
    return _favoritesCollection
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => FavoriteAddress.fromFirestore(doc))
            .toList());
  }
  
  // Obter favorito específico por tipo
  static Future<FavoriteAddress?> getFavoriteByType(FavoriteType type) async {
    try {
      final query = await _favoritesCollection
          .where('type', isEqualTo: type.name)
          .limit(1)
          .get();
          
      if (query.docs.isNotEmpty) {
        return FavoriteAddress.fromFirestore(query.docs.first);
      }
      return null;
    } catch (e) {
      print('Erro ao buscar favorito: $e');
      return null;
    }
  }
  
  // Remover favorito
  static Future<bool> removeFavorite(String favoriteId) async {
    try {
      await _favoritesCollection.doc(favoriteId).delete();
      return true;
    } catch (e) {
      print('Erro ao remover favorito: $e');
      return false;
    }
  }
  
  // Atualizar favorito
  static Future<bool> updateFavorite({
    required String favoriteId,
    required String name,
    String? icon,
  }) async {
    try {
      await _favoritesCollection.doc(favoriteId).update({
        'name': name,
        'icon': icon,
      });
      return true;
    } catch (e) {
      print('Erro ao atualizar favorito: $e');
      return false;
    }
  }
  
  // Verificar se endereço já é favorito
  static Future<bool> isAddressFavorite(AddressModel address) async {
    try {
      final query = await _favoritesCollection
          .where('address.latitude', isEqualTo: address.latitude)
          .where('address.longitude', isEqualTo: address.longitude)
          .get();
          
      return query.docs.isNotEmpty;
    } catch (e) {
      print('Erro ao verificar favorito: $e');
      return false;
    }
  }
}