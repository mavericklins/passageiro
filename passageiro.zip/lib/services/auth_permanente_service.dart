import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthPermanenteService {
  static const String _keyUsuarioLogado = 'usuario_logado';
  static const String _keyUsuarioUid = 'usuario_uid';
  static const String _keyUsuarioEmail = 'usuario_email';
  static const String _keyUsuarioNome = 'usuario_nome';
  static const String _keyUsuarioTelefone = 'usuario_telefone';
  static const String _keyDataLogin = 'data_login';

  /// Salva dados do usuário para login permanente
  static Future<void> salvarUsuarioLogado(User user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Buscar dados completos do usuário no Firestore
      Map<String, dynamic> dadosUsuario = {};
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('usuarios')
            .doc(user.uid)
            .get();
        
        if (userDoc.exists) {
          dadosUsuario = userDoc.data() ?? {};
        }
      } catch (e) {
        print('Erro ao buscar dados do usuário: $e');
      }

      // Salvar dados localmente
      await prefs.setBool(_keyUsuarioLogado, true);
      await prefs.setString(_keyUsuarioUid, user.uid);
      await prefs.setString(_keyUsuarioEmail, user.email ?? '');
      await prefs.setString(_keyUsuarioNome, dadosUsuario['nome'] ?? user.displayName ?? '');
      await prefs.setString(_keyUsuarioTelefone, dadosUsuario['telefone'] ?? user.phoneNumber ?? '');
      await prefs.setString(_keyDataLogin, DateTime.now().toIso8601String());

      print('✅ Usuário salvo localmente para login permanente: ${user.uid}');
    } catch (e) {
      print('❌ Erro ao salvar usuário localmente: $e');
    }
  }

  /// Verifica se usuário está logado permanentemente
  static Future<bool> isUsuarioLogado() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyUsuarioLogado) ?? false;
    } catch (e) {
      print('Erro ao verificar login: $e');
      return false;
    }
  }

  /// Obtém dados do usuário salvos localmente
  static Future<Map<String, String?>> getDadosUsuarioLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      return {
        'uid': prefs.getString(_keyUsuarioUid),
        'email': prefs.getString(_keyUsuarioEmail),
        'nome': prefs.getString(_keyUsuarioNome),
        'telefone': prefs.getString(_keyUsuarioTelefone),
        'dataLogin': prefs.getString(_keyDataLogin),
      };
    } catch (e) {
      print('Erro ao obter dados locais: $e');
      return {};
    }
  }

  /// Remove dados do usuário (logout)
  static Future<void> logout() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      await FirebaseAuth.instance.signOut();
      print('✅ Logout realizado');
    } catch (e) {
      print('Erro no logout: $e');
    }
  }

  /// Força login permanente - nunca expira
  static Future<User?> getUsuarioSempreLogado() async {
    try {
      // 1. Tentar usuário do Firebase Auth primeiro
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        print('✅ Usuário do Firebase Auth: ${user.uid}');
        return user;
      }

      // 2. Verificar se há dados salvos localmente
      final dadosLocais = await getDadosUsuarioLocal();
      final isLogado = await isUsuarioLogado();
      
      if (isLogado && dadosLocais['uid'] != null) {
        print('✅ Usuário salvo localmente: ${dadosLocais['uid']}');
        
        // Tentar reautenticar silenciosamente
        try {
          // Aguardar um pouco para Firebase inicializar
          await Future.delayed(Duration(seconds: 1));
          user = FirebaseAuth.instance.currentUser;
          
          if (user != null && user.uid == dadosLocais['uid']) {
            print('✅ Reautenticação silenciosa bem-sucedida');
            return user;
          }
        } catch (e) {
          print('Erro na reautenticação silenciosa: $e');
        }
        
        print('⚠️ Usando dados locais como fallback');
        return null; // Retorna null mas dados locais serão usados
      }

      print('❌ Nenhum usuário encontrado');
      return null;
    } catch (e) {
      print('❌ Erro ao obter usuário sempre logado: $e');
      return null;
    }
  }
}

