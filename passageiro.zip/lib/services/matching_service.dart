import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async';
import 'dart:math' as math;

/// Serviço de matching para conectar passageiros com motoristas
class MatchingService {
  static final MatchingService _instance = MatchingService._internal();
  factory MatchingService() => _instance;
  MatchingService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  StreamSubscription<DocumentSnapshot>? _corridaSubscription;
  String? _currentCorridaId;
  
  // Callbacks para atualizações
  Function(String status, Map<String, dynamic>? motoristaData)? onStatusUpdate;
  Function(String message)? onError;

  /// Iniciar monitoramento de uma corrida específica
  void startMonitoring(String corridaId) {
    _currentCorridaId = corridaId;
    
    print('🔍 MatchingService: Iniciando monitoramento da corrida $corridaId');
    
    // Cancelar monitoramento anterior se existir
    _corridaSubscription?.cancel();
    
    // Monitorar mudanças na corrida em tempo real
    _corridaSubscription = _firestore
        .collection('corridas')
        .doc(corridaId)
        .snapshots()
        .listen(
          _onCorridaUpdate,
          onError: (error) {
            print('❌ Erro no monitoramento da corrida: $error');
            onError?.call('Erro ao monitorar corrida: $error');
          },
        );
  }

  /// Parar monitoramento
  void stopMonitoring() {
    print('🛑 MatchingService: Parando monitoramento');
    _corridaSubscription?.cancel();
    _corridaSubscription = null;
    _currentCorridaId = null;
  }

  /// Quando há atualização na corrida
  void _onCorridaUpdate(DocumentSnapshot snapshot) {
    if (!snapshot.exists) {
      print('❌ Corrida não encontrada');
      onError?.call('Corrida não encontrada');
      return;
    }

    final data = snapshot.data() as Map<String, dynamic>;
    final status = data['status'] as String;
    final motoristaId = data['motoristaId'] as String?;
    
    print('📱 MatchingService: Status atualizado para $status');
    
    Map<String, dynamic>? motoristaData;
    
    // Se motorista foi atribuído, buscar dados dele
    if (motoristaId != null && motoristaId.isNotEmpty) {
      _buscarDadosMotorista(motoristaId).then((dados) {
        motoristaData = dados;
        onStatusUpdate?.call(status, motoristaData);
      });
    } else {
      onStatusUpdate?.call(status, null);
    }
  }

  /// Buscar dados do motorista
  Future<Map<String, dynamic>?> _buscarDadosMotorista(String motoristaId) async {
    try {
      print('👤 Buscando dados do motorista $motoristaId');
      
      final motoristaDoc = await _firestore
          .collection('motoristas')
          .doc(motoristaId)
          .get();
      
      if (motoristaDoc.exists) {
        final dados = motoristaDoc.data()!;
        print('✅ Dados do motorista encontrados: ${dados['nome']}');
        return dados;
      } else {
        print('❌ Motorista não encontrado');
        return null;
      }
    } catch (e) {
      print('❌ Erro ao buscar dados do motorista: $e');
      return null;
    }
  }

  /// Notificar motoristas próximos sobre nova corrida
  static Future<void> notifyNearbyDrivers(String corridaId) async {
    try {
      print('📢 Notificando motoristas sobre corrida $corridaId');
      
      // Buscar dados da corrida
      final corridaDoc = await FirebaseFirestore.instance
          .collection('corridas')
          .doc(corridaId)
          .get();
      
      if (!corridaDoc.exists) {
        print('❌ Corrida não encontrada para notificação');
        return;
      }
      
      final corridaData = corridaDoc.data()!;
      final origem = corridaData['origem'] as Map<String, dynamic>;
      final origemLat = origem['latitude'] as double;
      final origemLng = origem['longitude'] as double;
      
      // Buscar motoristas online próximos (raio de 10km)
      final motoristasQuery = await FirebaseFirestore.instance
          .collection('motoristas')
          .where('status', isEqualTo: 'online')
          .get();
      
      final batch = FirebaseFirestore.instance.batch();
      int notificacoesEnviadas = 0;
      
      for (final motoristaDoc in motoristasQuery.docs) {
        final motoristaData = motoristaDoc.data();
        final motoristaId = motoristaDoc.id;
        
        // Verificar se motorista tem localização
        if (motoristaData['latitude'] != null && motoristaData['longitude'] != null) {
          final motoristaLat = motoristaData['latitude'] as double;
          final motoristaLng = motoristaData['longitude'] as double;
          
          // Calcular distância (aproximada)
          final distancia = _calcularDistancia(
            origemLat, origemLng, 
            motoristaLat, motoristaLng
          );
          
          // Se está dentro do raio de 10km
          if (distancia <= 10.0) {
            // Verificar se motorista não rejeitou esta corrida
            final rejeitados = corridaData['motoristasRejeitados'] as List<dynamic>? ?? [];
            if (!rejeitados.contains(motoristaId)) {
              // Criar notificação para o motorista
              final notificacaoRef = FirebaseFirestore.instance
                  .collection('notificacoes_motorista')
                  .doc();
              
              batch.set(notificacaoRef, {
                'motoristaId': motoristaId,
                'corridaId': corridaId,
                'tipo': 'nova_corrida',
                'lida': false,
                'criadaEm': FieldValue.serverTimestamp(),
                'distancia': distancia,
                'origem': origem,
                'destino': corridaData['destino'],
                'valor': corridaData['valor'],
                'nomePassageiro': corridaData['nomePassageiro'],
              });
              
              notificacoesEnviadas++;
            }
          }
        }
      }
      
      // Executar batch de notificações
      if (notificacoesEnviadas > 0) {
        await batch.commit();
        print('✅ $notificacoesEnviadas notificações enviadas para motoristas');
      } else {
        print('⚠️ Nenhum motorista disponível encontrado');
      }
      
    } catch (e) {
      print('❌ Erro ao notificar motoristas: $e');
    }
  }

  /// Calcular distância aproximada entre dois pontos (em km)
  static double _calcularDistancia(double lat1, double lng1, double lat2, double lng2) {
    const double earthRadius = 6371; // Raio da Terra em km
    
    final double dLat = _degreesToRadians(lat2 - lat1);
    final double dLng = _degreesToRadians(lng2 - lng1);
    
    final double a = 
        math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_degreesToRadians(lat1)) * math.cos(_degreesToRadians(lat2)) * 
        math.sin(dLng / 2) * math.sin(dLng / 2);
    
    final double c = 2 * math.asin(math.sqrt(a));
    
    return earthRadius * c;
  }

  static double _degreesToRadians(double degrees) {
    return degrees * (math.pi / 180);
  }

  /// Cancelar corrida
  Future<void> cancelRide(String corridaId, String motivo) async {
    try {
      print('❌ Cancelando corrida $corridaId');
      
      await _firestore.collection('corridas').doc(corridaId).update({
        'status': 'cancelada',
        'motivoCancelamento': motivo,
        'canceladaEm': FieldValue.serverTimestamp(),
        'atualizadaEm': FieldValue.serverTimestamp(),
      });
      
      // Parar monitoramento
      stopMonitoring();
      
      print('✅ Corrida cancelada com sucesso');
    } catch (e) {
      print('❌ Erro ao cancelar corrida: $e');
      onError?.call('Erro ao cancelar corrida: $e');
    }
  }

  /// Dispose do serviço
  void dispose() {
    stopMonitoring();
  }
}

