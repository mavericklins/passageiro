import 'package:flutter/material.dart';

class VelloColors {
  // Cores principais da identidade Vello
  static const Color azul = Color(0xFF1B3A57);      // Azul principal
  static const Color laranja = Color(0xFFFF8C42);   // Laranja principal
  static const Color cinzaClaro = Color(0xFFF8F9FA); // Cinza claro de fundo
  
  // Variações do azul
  static const Color azulEscuro = Color(0xFF0F2A3F);
  static const Color azulClaro = Color(0xFF2B4A67);
  
  // Variações do laranja
  static const Color laranjaEscuro = Color(0xFFE67A35);
  static const Color laranjaClaro = Color(0xFFFFAD6F);
  
  // Cores de status
  static const Color sucesso = Color(0xFF28a745);    // Verde
  static const Color erro = Color(0xFFdc3545);       // Vermelho
  static const Color aviso = Color(0xFFffc107);      // Amarelo
  static const Color info = Color(0xFF17a2b8);       // Ciano
  
  // Cores neutras
  static const Color branco = Color(0xFFFFFFFF);
  static const Color preto = Color(0xFF000000);
  static const Color cinza100 = Color(0xFFf8f9fa);
  static const Color cinza200 = Color(0xFFe9ecef);
  static const Color cinza300 = Color(0xFFdee2e6);
  static const Color cinza400 = Color(0xFFced4da);
  static const Color cinza500 = Color(0xFFadb5bd);
  static const Color cinza600 = Color(0xFF6c757d);
  static const Color cinza700 = Color(0xFF495057);
  static const Color cinza800 = Color(0xFF343a40);
  static const Color cinza900 = Color(0xFF212529);
  
  // Cores de emergência
  static const Color emergencia = Color(0xFFE53E3E);
  static const Color emergenciaClaro = Color(0xFFFED7D7);
  
  // Gradientes
  static const LinearGradient gradientePrimario = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [azul, azulEscuro],
  );
  
  static const LinearGradient gradienteSecundario = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [laranja, laranjaEscuro],
  );
  
  static const LinearGradient gradienteEmergencia = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [emergencia, Color(0xFFDC143C)],
  );
  
  // Sombras
  static BoxShadow get sombraPadrao => BoxShadow(
    color: Colors.black.withOpacity(0.1),
    blurRadius: 10,
    offset: const Offset(0, 2),
  );
  
  static BoxShadow get sombraElevada => BoxShadow(
    color: Colors.black.withOpacity(0.15),
    blurRadius: 20,
    offset: const Offset(0, 4),
  );
  
  // Método para obter cor por nome
  static Color obterCor(String nomeCor) {
    switch (nomeCor.toLowerCase()) {
      case 'azul':
        return azul;
      case 'laranja':
        return laranja;
      case 'cinza_claro':
        return cinzaClaro;
      case 'sucesso':
        return sucesso;
      case 'erro':
        return erro;
      case 'aviso':
        return aviso;
      case 'info':
        return info;
      case 'emergencia':
        return emergencia;
      default:
        return azul;
    }
  }
  
  // Método para obter cor com opacidade
  static Color comOpacidade(Color cor, double opacidade) {
    return cor.withOpacity(opacidade);
  }
}