// ARQUIVO REMOVIDO - Usar VelloColors de app_colors.dart
// Este arquivo foi consolidado em lib/constants/app_colors.dart
// para manter consistência no sistema de cores do Vello Passageiro

export '../constants/app_colors.dart';