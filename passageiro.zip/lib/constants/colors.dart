import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFFFF6600); // Laranja Vello
