import 'package:flutter/material.dart';

class HistoricoScreen extends StatefulWidget {
  const HistoricoScreen({super.key});

  @override
  State<HistoricoScreen> createState() => _HistoricoScreenState();
}

class _HistoricoScreenState extends State<HistoricoScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  
  // Cores da identidade visual Vello
  static const Color velloBlue = Color(0xFF1B3A57);
  static const Color velloOrange = Color(0xFFFF8C42);
  static const Color velloLightGray = Color(0xFFF8F9FA);
  static const Color velloCardBackground = Color(0xFFFFFFFF);

  // Dados simulados do histórico
  final List<Map<String, dynamic>> corridasRecentes = [
    {
      'destino': 'Shopping Center Norte',
      'data': '15 Jan 2024',
      'hora': '14:30',
      'valor': 'R\$ 18,50',
      'status': 'Concluída',
      'distancia': '8,2 km',
      'tempo': '25 min',
      'motorista': 'Carlos Silva',
      'avaliacao': 4.8,
    },
    {
      'destino': 'Aeroporto Internacional',
      'data': '12 Jan 2024',
      'hora': '06:15',
      'valor': 'R\$ 45,00',
      'status': 'Concluída',
      'distancia': '32,1 km',
      'tempo': '48 min',
      'motorista': 'Ana Santos',
      'avaliacao': 5.0,
    },
    {
      'destino': 'Centro da Cidade',
      'data': '10 Jan 2024',
      'hora': '18:45',
      'valor': 'R\$ 12,30',
      'status': 'Concluída',
      'distancia': '5,7 km',
      'tempo': '18 min',
      'motorista': 'João Oliveira',
      'avaliacao': 4.5,
    },
  ];

  final List<Map<String, dynamic>> corridasCanceladas = [
    {
      'destino': 'Universidade Federal',
      'data': '08 Jan 2024',
      'hora': '09:20',
      'motivo': 'Cancelada pelo usuário',
      'status': 'Cancelada',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              velloCardBackground, // Branco no topo
              velloLightGray, // Cinza claro no meio
              velloCardBackground, // Branco na base
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header personalizado
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: velloCardBackground,
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(24),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: velloOrange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              Icons.arrow_back,
                              color: velloOrange,
                              size: 24,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Histórico',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: velloBlue,
                                ),
                              ),
                              Text(
                                'Suas viagens anteriores',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: velloBlue.withOpacity(0.6),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: velloBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.history,
                            color: velloBlue,
                            size: 24,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // TabBar personalizada
                    Container(
                      decoration: BoxDecoration(
                        color: velloLightGray,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        indicator: BoxDecoration(
                          color: velloOrange,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        labelColor: Colors.white,
                        unselectedLabelColor: velloBlue,
                        labelStyle: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                        unselectedLabelStyle: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                        tabs: const [
                          Tab(text: 'Concluídas'),
                          Tab(text: 'Canceladas'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Conteúdo das abas
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildCorridasConcluidas(),
                    _buildCorridasCanceladas(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCorridasConcluidas() {
    if (corridasRecentes.isEmpty) {
      return _buildEmptyState(
        icon: Icons.directions_car,
        title: 'Nenhuma viagem encontrada',
        subtitle: 'Suas viagens concluídas aparecerão aqui',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: corridasRecentes.length,
      itemBuilder: (context, index) {
        final corrida = corridasRecentes[index];
        return _buildCorridaCard(corrida, false);
      },
    );
  }

  Widget _buildCorridasCanceladas() {
    if (corridasCanceladas.isEmpty) {
      return _buildEmptyState(
        icon: Icons.cancel,
        title: 'Nenhuma viagem cancelada',
        subtitle: 'Suas viagens canceladas aparecerão aqui',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: corridasCanceladas.length,
      itemBuilder: (context, index) {
        final corrida = corridasCanceladas[index];
        return _buildCorridaCard(corrida, true);
      },
    );
  }

  Widget _buildCorridaCard(Map<String, dynamic> corrida, bool isCancelada) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: velloCardBackground,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isCancelada 
                    ? Colors.red.withOpacity(0.1)
                    : velloOrange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isCancelada ? Icons.cancel : Icons.location_on,
                  color: isCancelada ? Colors.red : velloOrange,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      corrida['destino'],
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: velloBlue,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${corrida['data']} • ${corrida['hora']}',
                      style: TextStyle(
                        fontSize: 14,
                        color: velloBlue.withOpacity(0.6),
                      ),
                    ),
                  ],
                ),
              ),
              if (!isCancelada)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    corrida['status'],
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
          
          if (!isCancelada) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: velloLightGray,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _buildInfoItem(
                      'Valor',
                      corrida['valor'],
                      Icons.attach_money,
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 40,
                    color: Colors.grey[300],
                  ),
                  Expanded(
                    child: _buildInfoItem(
                      'Distância',
                      corrida['distancia'],
                      Icons.straighten,
                    ),
                  ),
                  Container(
                    width: 1,
                    height: 40,
                    color: Colors.grey[300],
                  ),
                  Expanded(
                    child: _buildInfoItem(
                      'Tempo',
                      corrida['tempo'],
                      Icons.access_time,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(
                  Icons.person,
                  color: velloBlue.withOpacity(0.6),
                  size: 16,
                ),
                const SizedBox(width: 8),
                Text(
                  'Motorista: ${corrida['motorista']}',
                  style: TextStyle(
                    fontSize: 14,
                    color: velloBlue.withOpacity(0.8),
                  ),
                ),
                const Spacer(),
                Row(
                  children: [
                    Icon(
                      Icons.star,
                      color: Colors.amber,
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      corrida['avaliacao'].toString(),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: velloBlue,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ] else ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: Colors.red,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    corrida['motivo'],
                    style: const TextStyle(
                      color: Colors.red,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(
          icon,
          color: velloOrange,
          size: 20,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: velloBlue.withOpacity(0.6),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: velloBlue,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: velloOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                icon,
                size: 64,
                color: velloOrange,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: velloBlue,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 16,
                color: velloBlue.withOpacity(0.6),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

