// lib/screens/home/home_controller.dart
import 'package:flutter/material.dart';

class HomeController {
  final TextEditingController destinationController = TextEditingController();

  // Cores da identidade visual Vello
  static const Color velloBlue = Color(0xFF1B3A57);
  static const Color velloOrange = Color(0xFFFF8C42);
  static const Color velloLightGray = Color(0xFFF8F9FA);
  static const Color velloCardBackground = Color(0xFFFFFFFF);

  String distanceEstimate = '4,5 km';
  String priceEstimate = 'R\$ 15,00';

  void init(BuildContext context) {
    // Aqui você pode buscar localização atual, permissões, etc.
    print('Controller iniciado com identidade visual Vello!');
  }

  void requestRide() {
    // Lógica para solicitar corrida (exemplo simples)
    print('Solicitando corrida para: ${destinationController.text}');
  }

  void dispose() {
    destinationController.dispose();
  }

  // Método para obter cor primária da Vello
  Color getPrimaryColor() => velloBlue;

  // Método para obter cor de destaque da Vello
  Color getAccentColor() => velloOrange;

  // Método para obter cor de fundo da Vello
  Color getBackgroundColor() => velloLightGray;

  // Método para obter cor de cards da Vello
  Color getCardColor() => velloCardBackground;
}

