import 'package:flutter/material.dart';
import 'alterar_senha_screen.dart';
import 'sobre_app_screen.dart';
import 'privacidade_screen.dart';
import 'notificacoes_screen.dart';
import 'suporte_screen.dart';

class ConfiguracoesScreen extends StatelessWidget {
  const ConfiguracoesScreen({super.key});

  // Cores da identidade visual Vello
  static const Color velloBlue = Color(0xFF1B3A57);
  static const Color velloOrange = Color(0xFFFF8C42);
  static const Color velloLightGray = Color(0xFFF8F9FA);
  static const Color velloCardBackground = Color(0xFFFFFFFF);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: velloLightGray,
      appBar: AppBar(
        title: const Text(
          'Configurações',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        backgroundColor: velloBlue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildConfigCard(
              context,
              icon: Icons.lock_outline,
              iconColor: const Color(0xFF8B5CF6),
              title: 'Alterar Senha',
              subtitle: 'Mantenha sua conta segura',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AlterarSenhaScreen()),
                );
              },
            ),
            _buildConfigCard(
              context,
              icon: Icons.info_outline,
              iconColor: const Color(0xFF06B6D4),
              title: 'Sobre o Aplicativo',
              subtitle: 'Informações sobre a Vello',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SobreAppScreen()),
                );
              },
            ),
            _buildConfigCard(
              context,
              icon: Icons.privacy_tip_outlined,
              iconColor: const Color(0xFF10B981),
              title: 'Privacidade',
              subtitle: 'Política de privacidade e dados',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PrivacidadeScreen()),
                );
              },
            ),
            _buildConfigCard(
              context,
              icon: Icons.notifications_outlined,
              iconColor: velloOrange,
              title: 'Notificações',
              subtitle: 'Gerencie suas notificações',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NotificacoesScreen()),
                );
              },
            ),
            _buildConfigCard(
              context,
              icon: Icons.support_agent_outlined,
              iconColor: const Color(0xFF6366F1),
              title: 'Suporte',
              subtitle: 'Precisa de ajuda? Entre em contato',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SuporteScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfigCard(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: velloCardBackground,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            spreadRadius: 0,
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: iconColor,
            size: 24,
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: velloBlue,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        trailing: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: velloOrange.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(
            Icons.arrow_forward_ios,
            color: velloOrange,
            size: 16,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

